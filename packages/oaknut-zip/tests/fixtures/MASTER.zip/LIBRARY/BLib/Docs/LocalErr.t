                  Local error handler for 6502 BBC BASIC
                  ======================================
                File: LocalError, LocalErr -- Update: 0.20
                 Author: J.G.Harston -- Date: 15-Oct-2016

The LocalError and LocalErr libraries allow you to use an ON ERROR LOCAL
local error handler within subroutines. LocalErr only works within PROCs and
has its own syntax, LocalError works within PROCs and FNs and uses the
standard syntax used on other BBC BASICs.

PROCerr_local(action)
---------------------
A program must call PROCerr_local(1) on starting up to connect the extended
error handler. PROCerr_local(0) must be called to disconnect the error
handler before the program exits. If not running on 6502 BASIC it returns
immediately, so can be included in code intended to run on multiple
platforms.

Local error handler
-------------------
Within a subroutine you set up a local error handler with:

LocalErr:     LOCAL !&16:ON ERROR LOCAL commands...
LocalError:   LOCAL ERROR:ON ERROR LOCAL commands...

When an error occurs while the local error handler is active the error
handler is entered with the stack ready for the subroutine to return. The
caller's error handler is restored when the subroutine returns with ENDPROC
or =<value>.

Examples
--------
Using LocalError
~~~~~~~~~~~~~~~~
  DEFFNopen(in$)
  LOCAL ERROR:ON ERROR LOCAL =0
  =OPENIN(in$)

  DEFPROCcommand(A$)
  LOCAL ERROR:ON ERROR LOCAL IF ERR=254 THEN ENDPROC ELSE REPORT:PRINT:ENDPROC
  OSCLI A$
  ENDPROC

Using LocalErr
~~~~~~~~~~~~~~
  DEFPROCcommand(A$)
  LOCAL !&16:ON ERROR LOCAL IF ERR=254 THEN ENDPROC ELSE REPORT:PRINT:ENDPROC
  OSCLI A$
  ENDPROC
  
Notes
-----
Note that the library functions won't magically prevent errors or incorrect
operation from using badly nested structues. The ON ERROR LOCAL must be within
the structure it is trapping.

For instance, this is incorrect:
    DEFPROCfoo
    LOCAL ERROR:ON ERROR LOCAL:NEXT a
    FOR a=1 TO 10
      ...
    NEXT a
    ENDPROC

This is correct:
    DEFPROCfoo
    LOCAL ERROR
    FOR a=1 TO 10
      ON ERROR LOCAL:NEXT a:ENDPROC
      ...
    NEXT a
    ENDPROC

or:
    DEFPROCfoo
    LOCAL ERROR:ON ERROR LOCAL:ENDPROC
    FOR a=1 TO 10
      ...
    NEXT a
    ENDPROC
